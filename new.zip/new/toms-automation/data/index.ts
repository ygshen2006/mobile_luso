const skus = require("./skus.json").filter(_ => _.sspPrice != undefined);

export class DataManager {
    private static manager?: DataManager = new DataManager();
    private readonly skus;
    constructor() {
        this.skus = skus;
    }

    static getSkus() {
        return this.manager?.skus;
    }
}