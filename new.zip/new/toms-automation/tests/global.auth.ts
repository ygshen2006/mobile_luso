import { test as setup } from '@playwright/test'
import { UserNameLoginPage } from '../pages/login/user.name.login';
import { HomePage } from '../pages/home/home-page';
import { SapInventoryPage } from '../pages/inventory/sap-inventory-page';
// const authFile = 'playwright/.auth/user.json';
setup.skip('auth', async ({ page }, testInfo) => {
    const UserLoginPage = new UserNameLoginPage(page);
    await UserLoginPage.goto("https://tomsuat.dyson.cn/ofs.html?customer=dyson-ofs-test&lang=zh");

    await UserLoginPage.login();
    const homePage = new HomePage(page);
    await homePage.search("SAP库存查询");
    const sapInventoryPage = new SapInventoryPage(page);

    const both = [
        "473817-01",
        "969762-02",
        "00SA1042"
    ].map((_ => {
        return {
            sku: _,
            values: [
                {
                    "facilityCode": "JDL (8951)",
                    "attribute1": "1000",
                    "count": "100"
                },

                {
                    "facilityCode": "LF (8952)",
                    "attribute1": "1000",
                    "count": "100"
                },
            ]
        }
    }));

    const neither = [
        "407217-01",
        "971852-01"
    ].map((_ => {
        return {
            sku: _,
            values: [
                {
                    "facilityCode": "JDL (8951)",
                    "attribute1": "1000",
                    "count": "-100"
                },

                {
                    "facilityCode": "LF (8952)",
                    "attribute1": "1000",
                    "count": "-1000"
                },
            ]
        }
    }));
    const i_8951 = [
        "282820-01",
        "966563-07"
    ].map(_ => {
        return {
            sku: _,
            values: [
                {
                    "facilityCode": "JDL (8951)",
                    "attribute1": "1000",
                    "count": "100"
                },
                {
                    "facilityCode": "LF (8952)",
                    "attribute1": "1000",
                    "count": "-100"
                }
            ]
        }
    });
    const i_8952 = [
        "448592-01",
        "400458-01",
        "965003-05",
        "967719-04",
        "970445-05"
    ].map(_ => {
        return {
            sku: _,
            values: [
                {
                    "facilityCode": "LF (8952)",
                    "attribute1": "1000",
                    "count": "100"
                },
                {
                    "facilityCode": "JDL (8951)",
                    "attribute1": "1000",
                    "count": "-100"
                }
            ]
        }
    });

    const datas = [...both, ...neither, ...i_8951, ...i_8952];
    for (const data of datas) {
        await sapInventoryPage.searchItemBySku(data.sku);
        for (const value of data.values) {
            const result = await sapInventoryPage.checkItem([{ field: 'skuCode', value: `${data.sku}` }, { field: 'facilityCode', value: `${value.facilityCode}` }, { field: 'attribute1', value: value.attribute1 }])

            if (result) {
                let count = value.count;
                if (value.count.indexOf('-') != -1) {
                    if (result['availableQty'] === "0" || result['availableQty'].indexOf("-") !== -1) continue;
                    count = `-${result['availableQty']}`;
                }
                await sapInventoryPage.changeCount(count);
            }
        }
    }
    // await page.goto('https://tomsuat.dyson.cn/ofs.html?customer=dyson-ofs-test&lang=zh');

    // // page.set_viewport_size({ width: 1960, height: 1080 });
    // await page.keyboard.press("Tab");
    // await page.keyboard.press("Tab");
    // await page.keyboard.press("Tab");

    // await page.keyboard.down('Enter');

    // const userName = page.locator('input[placeHolder="Enter a username, email, or phone number"]');
    // await userName.focus();
    // await page.waitForTimeout(500);
    // await userName.type("john.c.shen@dyson.com",{delay:100});
    // const password = page.locator("input[type='password']");
    // await password.focus();
    // await page.waitForTimeout(500);
    // await password.type("Family~!@#`123",{delay:100});

    // const logonButton = page.locator(".ivu-btn-primary");
    // await logonButton.click();
    // // await page.getByLabel('Username or email address').fill('ygshen2006@163.com');
    // // await page.getByLabel('Password').fill('@123');
    // // await page.locator('input[name="commit"]').click();
    // // await page.waitForURL('https://tomsuat.dyson.cn/ofs.html?customer=dyson-ofs-test&lang=zh');
    // await page.context().storageState({ path: authFile });

});