import { OrderManager } from "../api/order";
import { AndOr } from "../components/common/types/common/and-or";
import { GiveAway } from "../components/common/types/promptions/give-away-method";
import { PromptionStrategy } from "../components/common/types/promptions/strategy";
import { PromptionProductType } from "../components/common/types/promptions/product-type";
import { PromptionRaisingMethod } from "../components/common/types/promptions/raising-method";
import { STORE } from "../components/common/types/common/stores";
import { expect, test } from "../fixture/pages/user.login";
import { HomePage } from "../pages/home/home-page";
import { SapInventoryPage } from "../pages/inventory/sap-inventory-page";
import { PromptionStratergyNewPage } from "../pages/promptions/strategy/new.page";
import { PromptionStrategyListPage } from "../pages/promptions/strategy/list.page";
import { PromptionPlanListPage } from "../pages/promptions/plan/list.page";
import { YesOrNo } from "../components/common/types/common/yes-or-no";
import { PromptionPlan } from "../components/common/types/promptions/plan";
import { PromptionPlanNewPage } from "../pages/promptions/plan/new.page";
import { EnableDisable } from "../components/common/types/common/enable-disable";


test.beforeAll(async () => {
  // disable policy created
});
test.skip('test create order', async ({ }) => {
  const manager: OrderManager = new OrderManager();
  const result = await manager.createOrder({
    "skuCodes": [{
      "sku": "00SA1042",
      "productType": "Non-GWP",
      "count": 2
    }],
    "sourcePlatformCode": ""
  });

  if (result.error == false) {
    console.log(result.orderId);
  }
});
test('创建促销策略、促销计划', async ({ page, UserLoginPage }) => {
  await UserLoginPage.login();
  const homePage = new HomePage(page);
  await homePage.search("促销策略");

  // 创建促销策略
  const promptionStrategyListPage = new PromptionStrategyListPage(page);
  await promptionStrategyListPage.clickNew();
  var strategyName = "test_new_4";
  var mainSku = ["473817-01"];
  var subSku = "967719-04";
  const promption: PromptionStrategy = {
    header: {
      name: strategyName,
      store: STORE.PDD,
      giveAwayMethod: GiveAway.FIXED,
      accumulation: YesOrNo.N,
      relations: AndOr.And,
      comment: 'For automation',
      enable: true
    },
    requirments: [
      {
        row: 0,
        logic: '等于',
        values: ['普通订单']
      }
    ],
    activities: [
      {
        row: 0,
        logic: '大于等于',
        count: "1",
        skus: mainSku
      }
    ],
    promptionSkus: [
      {
        sku: subSku,
        count: "1",
        raisingMethod: PromptionRaisingMethod.DZ,
        productType: PromptionProductType["2-Dyson GWP"]
      }
    ]
  };
  const promptionNewPage = new PromptionStratergyNewPage(page);
  await promptionNewPage.create(promption);
  await homePage.refresh();
  await homePage.search("促销策略");
  await promptionStrategyListPage.search({ name: strategyName, allowed: YesOrNo.N });
  await promptionStrategyListPage.clickAudit();

  await promptionStrategyListPage.search({ name: strategyName, allowed: YesOrNo.Y });
  const datas = await promptionStrategyListPage.getData();
  var found = datas.find(_ => _.name == strategyName && _.auditInd === "是");
  expect(found).not.toBeNull();
  strategyName = `${found!!['code']} ${found!!['name']}`;
  const planName = "test plan9";
  // 创建促销计划
  await homePage.refresh();
  await homePage.search("促销计划");
  const promptionPlanListPage = new PromptionPlanListPage(page);
  await promptionPlanListPage.clickNew();

  const plan: PromptionPlan = {
    header: {
      name: planName,
      store: STORE.PDD,
      startDate: "2024-01-01",
      startTime: "00:00:01",
      endDate: "2024-12-11",
      endTime: "00:00:01"
    },
    strategy: {
      name: strategyName,
      group: "1",
      priority: "1",
      payStartDate: "2024-05-31",
      payStartTime: "01:00:00",
      payEndDate: "2024-06-30",
      payEndTime: "01:00:00"
    }
  };

  const promptionPlanNewPage: PromptionPlanNewPage = new PromptionPlanNewPage(page);
  await promptionPlanNewPage.create(plan);

  // 审核计划
  await homePage.refresh();
  await homePage.search("促销计划");
  await promptionPlanListPage.search({ name: planName, status: EnableDisable.N });
  await promptionPlanListPage.clickEnable();
});