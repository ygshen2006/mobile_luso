import { test as base } from "@playwright/test"
import { UserNameLoginPage } from "../../pages/login/user.name.login";

type Login = {
    UserLoginPage: UserNameLoginPage
};


const test = base.extend<Login>({
    UserLoginPage: async ({ baseURL, page }, use) => {
        const loginPage = new UserNameLoginPage(page);
        await loginPage.goto(baseURL);
        await use(loginPage);
    }
});
test.use({ baseURL: process.env.BASEURL ? process.env.BASEURL : "https://tomsuat.dyson.cn/ofs.html?customer=dyson-ofs-test&lang=zh" });
export { test }
export { expect } from '@playwright/test';