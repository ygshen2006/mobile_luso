import { Page } from "@playwright/test";
import { BasePage } from "../base.page";
import { SearchArea } from "../../components/common/search-area";

export class HomePage extends BasePage {
    //SAP库存查询

    private readonly searchArea = new SearchArea(this.page);

    constructor(page: Page) {
        super(page);
    }

    async search(text){
        await this.searchArea.select(text);
    }

    async refresh(){
        await this.page.reload();
    }
}