import { Page } from "@playwright/test";
import { GridComponent } from "../../../components/common/grid";
import { PromptionSearchModel } from "../../../components/common/types/promptions/search-model";
import { SearchClause } from "../../../components/common/types/common/search-clause";
import { PromptionPlanSearchComponent } from "../../../components/promptions/search/search-plan-header";

export class PromptionPlanListPage {
    private readonly searchArea: PromptionPlanSearchComponent = new PromptionPlanSearchComponent(this.page);
    private readonly RESULT_AREA: GridComponent = new GridComponent(this.page, this.page.locator('.ttxBill div[role="tabpanel"]').nth(0));
    constructor(public readonly page: Page) { }

    async clickNew() {
        await this.RESULT_AREA.gridHeader.clickActionButton("新增");
    }

    async clickEnable() {
        await this.RESULT_AREA.gridHeader.clickActionButton("启用");
    }
    async clickDisable() {
        await this.RESULT_AREA.gridHeader.clickActionButton("禁用");
    }

    async search(clause: PromptionSearchModel) {
        await this.searchArea.inputSearch(clause);
        await this.RESULT_AREA.gridHeader.clickActionButton("查询");

        const clauses: SearchClause[] = [];
        if (clause.name) clauses.push({ field: 'name', value: clause.name });
        if (clause.code) clauses.push({ field: 'code', value: clause.code });
        if (clause.status) clauses.push({ field: 'status', value: clause.status });
        // if (clause.stores) clauses.push({ field: 'storeCode', value: clause.stores });

        await this.RESULT_AREA.gridMain.clickRowBySearch(clauses);
    }

    async getData(){
        return await this.RESULT_AREA.gridMain.getDatas();
    }
}