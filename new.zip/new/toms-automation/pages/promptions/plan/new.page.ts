import { Page } from "@playwright/test";
import { PromptionActionsComponent } from "../../../components/promptions/action";
import { GridComponent } from "../../../components/common/grid";
import { PromptionPlanHeaderComponent } from "../../../components/promptions/plan/header";
import { PromptionPlan } from "../../../components/common/types/promptions/plan";
import { AddStrategyIntoPlanComponent } from "../../../components/promptions/dialogs/add-strategy-into-plan-component";
import { OkCancelComponent } from "../../../components/common/controls/ok-cancel-component";

export class PromptionPlanNewPage {
    private readonly promptionHeader: PromptionPlanHeaderComponent = new PromptionPlanHeaderComponent(this.page);
    private readonly promptionAction: PromptionActionsComponent = new PromptionActionsComponent(this.page, this.page.locator('.ttxBill div[role="tabpanel"]').nth(1));

    private readonly strategySelectGrid: GridComponent = new GridComponent(this.page, this.page.locator('.ttxBill div[role="tabpanel"] .listGridContainer').nth(1));

    private readonly VISIBLE_DIALOG = this.page.locator('.dijitDialog:visible');
    private readonly STRATEGY_SELECT_DIALOG = new AddStrategyIntoPlanComponent(this.page, this.VISIBLE_DIALOG);
    private readonly OK_CANCEL_BUTTONS: OkCancelComponent = new OkCancelComponent(this.page, this.VISIBLE_DIALOG);

    constructor(public readonly page: Page) {

    }

    async create(promptionPlan: PromptionPlan) {
        // set header
        await this.promptionHeader.editHeader(promptionPlan);
        await this.promptionAction.clickSave();
        await this.page.waitForTimeout(1000);
        await this.strategySelectGrid.gridHeader.clickActionButton("新增明细");
        await this.STRATEGY_SELECT_DIALOG.chooseStrategy(promptionPlan);
        await this.OK_CANCEL_BUTTONS.confirm();
        await this.promptionAction.clickSave();
    }
} 