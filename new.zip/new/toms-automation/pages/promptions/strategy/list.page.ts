import { Page } from "@playwright/test";
// import { FilterSearchArea } from "../../components/common/filter-header";
import { GridComponent } from "../../../components/common/grid";
import { PromptionStrategySearchComponent } from "../../../components/promptions/search/search-strategy-header";
import { PromptionSearchModel } from "../../../components/common/types/promptions/search-model";
import { SearchClause } from "../../../components/common/types/common/search-clause";

export class PromptionStrategyListPage {
    private readonly searchArea: PromptionStrategySearchComponent = new PromptionStrategySearchComponent(this.page);
    private readonly RESULT_AREA: GridComponent = new GridComponent(this.page, this.page.locator('.PromotionPolicy div[role="tabpanel"]').nth(0));
    constructor(public readonly page: Page) { }

    async clickNew() {
        await this.RESULT_AREA.gridHeader.clickActionButton("新增");
    }

    async clickAudit() {
        await this.RESULT_AREA.gridHeader.clickActionButton("审核");
    }
    async search(clause: PromptionSearchModel) {
        await this.searchArea.inputSearch(clause);
        await this.RESULT_AREA.gridHeader.clickActionButton("查询");

        const clauses: SearchClause[] = [];
        if (clause.name) clauses.push({ field: 'name', value: clause.name });
        if (clause.code) clauses.push({ field: 'code', value: clause.code });
        if (clause.allowed) clauses.push({ field: 'auditInd', value: clause.allowed });

        await this.RESULT_AREA.gridMain.clickRowBySearch(clauses);
    }

    async getData(){
        return await this.RESULT_AREA.gridMain.getDatas();
    }
}