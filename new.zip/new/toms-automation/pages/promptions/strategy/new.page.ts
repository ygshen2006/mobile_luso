import { Page } from "@playwright/test";
import { PromptionStrategyHeaderComponent } from "../../../components/promptions/strategy/header";
import { PromptionStrategy } from "../../../components/common/types/promptions/strategy";
import { PromptionActionsComponent } from "../../../components/promptions/action";
import { PromptionStrategyRequirementComponent } from "../../../components/promptions/strategy/requirement";
import { PromptionStrategyActivityComponent } from "../../../components/promptions/strategy/activity";
import { GridComponent } from "../../../components/common/grid";
import { AddSkuComponent } from "../../../components/promptions/dialogs/add-sku-component";
import { SkuSearchModel } from "../../../components/common/types/common/sku-search-model";
import { OkCancelComponent } from "../../../components/common/controls/ok-cancel-component";

export class PromptionStratergyNewPage {
    private readonly promptionHeader: PromptionStrategyHeaderComponent = new PromptionStrategyHeaderComponent(this.page);
    private readonly promptionAction: PromptionActionsComponent = new PromptionActionsComponent(this.page, this.page.locator('.PromotionPolicy div[role="tabpanel"]').nth(1));
    private readonly promptionRequirement: PromptionStrategyRequirementComponent = new PromptionStrategyRequirementComponent(this.page);
    private readonly promptionActivity: PromptionStrategyActivityComponent = new PromptionStrategyActivityComponent(this.page);

    private readonly promptionSkusGrid: GridComponent = new GridComponent(this.page, this.page.locator('.promotionGift'));

    private readonly PARENT = this.page.locator('.dijitDialog:visible');
    private readonly addPromptionSkuDialog: AddSkuComponent = new AddSkuComponent(this.page, this.PARENT, "SKU编码");
    private readonly okCancelButtons: OkCancelComponent = new OkCancelComponent(this.page, this.PARENT);

    constructor(public readonly page: Page) {

    }

    async create(promption: PromptionStrategy) {
        // set header
        await this.promptionHeader.editHeader(promption);
        await this.promptionAction.clickSave();

        // set requirement
        for (const value of promption.requirments) {
            if (value.row == 0) {
                await this.promptionRequirement.selectLogic(value.logic, value.row);
                await this.promptionRequirement.selectOrderType(value.values, value.row);
            }
        }
        await this.promptionAction.clickSave();

        // set main skus
        for (const value of promption.activities) {
            if (value.row == 0) {
                await this.promptionActivity.selectLogic(value.logic, value.row);
                await this.promptionActivity.setValue(value.count, value.row);
                await this.promptionAction.clickSave();
                await this.promptionActivity.selectSkus(value.skus, value.row);
            }
        }
        await this.promptionAction.clickSave();

        // Set additional skus
        for (const _ of promption.promptionSkus) {
            await this.promptionSkusGrid.gridHeader.clickActionButton("新增");
            const skuModel: SkuSearchModel = {
                codes: [_.sku]
            };
            // Select And save
            await this.addPromptionSkuDialog.selectSkus(skuModel);
            
            await this.addPromptionSkuDialog.configSku(_);

            await this.okCancelButtons.confirm();
            await this.okCancelButtons.cancel();  
        }
     
        await this.promptionAction.clickSave();
    }
} 