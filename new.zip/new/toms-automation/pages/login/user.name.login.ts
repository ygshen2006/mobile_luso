import { Locator, Page } from "playwright-core";
import { BasePage } from "../base.page";

export class UserNameLoginPage extends BasePage {

    private readonly userNameField = this.page.locator('input[placeHolder="Enter a username, email, or phone number"]');

    private readonly passwordField = this.page.locator("input[type='password']");


    private readonly logonButton = this.page.locator(".ivu-btn-primary");


    constructor(page: Page) {
        super(page);
    }
    async login(userName="john.c.shen@dyson.com", password="Family~!@#`123") {
        await this.page.keyboard.press("Tab");
        await this.page.keyboard.press("Tab");
        await this.page.keyboard.press("Tab");
      
        await this.page.keyboard.down('Enter');

        await this.userNameField.focus();
        await this.page.waitForTimeout(500);
        await this.userNameField.type(userName, { delay: 50 });

        await this.passwordField.focus();
        await this.page.waitForTimeout(500);
        await this.passwordField.type(password, { delay: 50 });

        await this.logonButton.click();
    }
}