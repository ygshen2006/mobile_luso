import { Page } from "@playwright/test";
import { FilterSearchArea } from "../../components/common/filter-header";
import { ChangeCountDialog } from "../../components/inventory/change.count.dialog";
import { GridComponent } from "../../components/common/grid";
import { SearchClause } from "../../components/common/types/common/search-clause";
export class SapInventoryPage {
    private readonly gridParentLocaltor = this.page.locator('div[data-dojo-attach-point="cpList"]');
    private readonly resultArea: GridComponent = new GridComponent(this.page, this.gridParentLocaltor);

    private readonly searchArea: FilterSearchArea = new FilterSearchArea(this.page);

    private readonly changeCountDialog: ChangeCountDialog = new ChangeCountDialog(this.page);
    constructor(public readonly page: Page) {

    }
    async searchItemBySku(skuName: string) {
        await this.searchArea.setField("SKU编码", skuName);
        await this.resultArea.gridHeader.clickActionButton("查询");
    }

    async checkItem(clauses: SearchClause[]) {
        return await this.resultArea.gridMain.clickRowBySearch(clauses);
    }

    async changeCount(count) {
        await this.page.waitForTimeout(500);
        await this.resultArea.gridHeader.clickActionButton("调整数量");
        await this.changeCountDialog.changeCount(count);
    }
}