const config = process.env;
const toms = {
    erpDomain: config.erpDomain,
    domain: config.domain,
    url: config.url,
    encryptKey: config.encryptKey,
    appKey: config.appKey,
    timeKey: config.timeKey,
    createOrderUri: config.createOrderUri
}
export { toms }