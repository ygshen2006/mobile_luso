import { Page } from "@playwright/test";
import { SearchSkuComponent } from "../search/search-sku-header";
import { GridComponent } from "../../common/grid";
import { SkuSearchModel } from "../../common/types/common/sku-search-model";
import { SearchClause } from "../../common/types/common/search-clause";
import { PromptionSku } from "../../common/types/promptions/sku";
import { ItemSelectComponent } from "../../common/controls/item.select.component";
// import { OkCancelComponent } from "../../common/controls/ok-cancel-component";

export class AddSkuComponent {
    private readonly SEARCH_AREA: SearchSkuComponent;
    private readonly SKU_GRID = new GridComponent(this.page, this.MAIN);
    constructor(public readonly page: Page,
        private readonly MAIN,
        private skuLabelText = 'SKU编码批量查询',
        private searchText: string = "查询") {
        this.SEARCH_AREA = new SearchSkuComponent(this.page, this.MAIN, skuLabelText, searchText);
    }

    async selectSkus(skuModel: SkuSearchModel) {
        await this.SEARCH_AREA.search(skuModel);

        var clauses: SearchClause[] = [];

        if (skuModel.codes && skuModel.codes.length > 0) {
            clauses = skuModel.codes.map(_ => {
                return {
                    field: 'code',
                    value: _
                }
            });
        }
        await this.SKU_GRID.gridMain.clickRowBySearch(clauses);
    }

    async configSku(sku: PromptionSku) {
        // count
        await (await this.SKU_GRID.gridMain.getCellLocator(0, "requestQty")).locator('input').nth(0).fill(sku.count);
        // Increase type
        const increaseTypeLocator = await this.SKU_GRID.gridMain.getCellLocator(0, "increaseType");
        const increaseTypeId = await increaseTypeLocator.locator('input[role="textbox"]').getAttribute('id');
        const increaseTypeComponent = new ItemSelectComponent(this.page, increaseTypeId!!);
        await increaseTypeComponent.select(sku.raisingMethod);

        // Product type
        const productTypeLocator = await this.SKU_GRID.gridMain.getCellLocator(0, "productType");
        const productTypeId = await productTypeLocator.locator('input[role="textbox"]').getAttribute('id');
        const productTypeComponent = new ItemSelectComponent(this.page, productTypeId!!);
        await productTypeComponent.select(sku.productType);


        // limit if limitedQty
        if (sku.limit) {
            await (await this.SKU_GRID.gridMain.getCellLocator(0, "limitedQty")).locator('input').fill(sku.limit);
        }
    }

}