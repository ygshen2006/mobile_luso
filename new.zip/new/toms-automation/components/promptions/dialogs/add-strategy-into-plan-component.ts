import { Locator, Page } from "@playwright/test";
import { ItemSelectComponent } from "../../common/controls/item.select.component";
import { DateTimeComponent } from "../../common/controls/date-time.component";
import { PromptionPlan } from "../../common/types/promptions/plan";
// import { OkCancelComponent } from "../../common/controls/ok-cancel-component";

export class AddStrategyIntoPlanComponent {
    private readonly PARENT: Locator;

    private readonly GROUP_ID_CONTROL: Locator;
    private readonly PRIORITY_CONTROL: Locator;

    private readonly PAY_START_TIME_CONTROL: DateTimeComponent;
    private readonly PAY_END_TIME_CONTROL: DateTimeComponent;


    constructor(public readonly page: Page,
        private readonly _parent: Locator) {
        this.PARENT = _parent;
        this.GROUP_ID_CONTROL = this.PARENT.getByLabel("组别");
        this.PRIORITY_CONTROL = this.PARENT.getByLabel("优先级");
        this.PAY_START_TIME_CONTROL = new DateTimeComponent(this.page, this.PARENT, "付款时间起")
        this.PAY_END_TIME_CONTROL = new DateTimeComponent(this.page, this.PARENT, "付款时间止")
    }

    async chooseStrategy(plan: PromptionPlan) {
        const {
            name,
            group,
            priority,
            payStartDate,
            payStartTime,
            payEndDate,
            payEndTime
        } = plan.strategy;

        const label_strategy = this.PARENT.locator('label[title="促销策略编码"]');
        const label_strategy_id = await label_strategy.getAttribute("for");
        const stategyControl = new ItemSelectComponent(this.page, label_strategy_id!!);

        await stategyControl.select(name);
        await this.GROUP_ID_CONTROL.clear();
        await this.GROUP_ID_CONTROL.fill(group!!);

        await this.PRIORITY_CONTROL.clear();
        await this.PRIORITY_CONTROL.fill(priority!!);

        await this.PAY_START_TIME_CONTROL.input(payStartDate, payStartTime);
        await this.PAY_END_TIME_CONTROL.input(payEndDate, payEndTime);
    }
}