import { Page } from "@playwright/test";
import { GridComponent } from "../../common/grid";
import { ItemSelectComponent } from "../../common/controls/item.select.component";
import { AddSkuComponent } from "../dialogs/add-sku-component";
import { SkuSearchModel } from "../../common/types/common/sku-search-model";
import { OkCancelComponent } from "../../common/controls/ok-cancel-component";

export class PromptionStrategyActivityComponent {

    private readonly ORDER_CONDITION_AREA = this.page.locator('.promotionCondition');

    private readonly REQUIREMENT_TABLE: GridComponent = new GridComponent(this.page, this.ORDER_CONDITION_AREA);

    private readonly PARENT = this.page.locator('.dijitDialog:visible');
    private readonly MAIN = this.PARENT.locator('.dijitTabPaneWrapper div[role="tabpanel"]').nth(0);
    private readonly SElECT_SKU_DIALOG: AddSkuComponent = new AddSkuComponent(this.page, this.MAIN);

    private readonly okCancelButtons: OkCancelComponent = new OkCancelComponent(this.page, this.PARENT);

    private selectLogicControl: ItemSelectComponent;
    constructor(public readonly page: Page) {

    }

    async selectLogic(text: string = "大于等于", row: number = 0) {
        const cell = await this.REQUIREMENT_TABLE.gridMain.getCellLocator(row, "andOr");
        const id = await cell.locator('input[role="textbox"]').getAttribute('id');
        this.selectLogicControl = new ItemSelectComponent(this.page, id!!);
        await this.selectLogicControl.select(text);
    }

    async setValue(value: string, row: number = 0) {
        const cell = await this.REQUIREMENT_TABLE.gridMain.getCellLocator(row, "value");
        await cell.locator('input').fill(value);
    }

    async selectSkus(values: string[], row: number = 0) {
        const skuModel: SkuSearchModel = {
            codes: values
        };
        await this.REQUIREMENT_TABLE.gridMain.clickCell(row, "promotionSku");
        await this.SElECT_SKU_DIALOG.selectSkus(skuModel);
        await this.okCancelButtons.confirm();
        await this.okCancelButtons.cancel();
    }
}

