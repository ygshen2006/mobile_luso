import { Page } from "@playwright/test";
import { PromptionStrategy } from "../../common/types/promptions/strategy";
import { ItemSelectComponent } from "../../common/controls/item.select.component";
import { ToggleComponent } from "../../common/controls/toggle.component";

export class PromptionStrategyHeaderComponent {
    private readonly HEADER_AREA = this.page.locator('.policyHeader');
    private readonly NAME_FIELD = this.HEADER_AREA.getByLabel("名称", { exact: true });
    private readonly STORE_FIELD_LABEL = this.HEADER_AREA.locator('label[title="店铺"]');

    private readonly GIVE_AWAY_METHOD_LABEL = this.HEADER_AREA.locator('label[title="赠送方式"]');
    private readonly ACCUMULATION_LABEL = this.HEADER_AREA.locator('label[title="累计"]');

    private readonly RELATION_LABEL = this.HEADER_AREA.locator('label[title="参与活动关系符"]');
    private readonly COMMENT_TEXT = this.HEADER_AREA.getByLabel("备注");
    private readonly ENABLE_LABEL = this.HEADER_AREA.locator('label[title="启用"]');

    constructor(public readonly page: Page) {

    }

    async editHeader(promption: PromptionStrategy) {
        await this.createHeader(promption);
    }

    async createHeader(promption: PromptionStrategy) {
        const storeId = await this.STORE_FIELD_LABEL.getAttribute("for");
        const giveMethodId = await this.GIVE_AWAY_METHOD_LABEL.getAttribute("for");
        const accumulationId = await this.ACCUMULATION_LABEL.getAttribute("for");
        const relationId = await this.RELATION_LABEL.getAttribute("for");
        const enableId = await this.ENABLE_LABEL.getAttribute("for");

        const selectStoreControl = new ItemSelectComponent(this.page, storeId!!);
        const giveAwayControl = new ItemSelectComponent(this.page, giveMethodId!!);
        const accumulationControl = new ItemSelectComponent(this.page, accumulationId!!);
        const relationControl = new ItemSelectComponent(this.page, relationId!!);
        const enableControl = new ToggleComponent(this.page, enableId!!);

        const {
            "header": {
                name,
                store,
                giveAwayMethod,
                relations,
                accumulation,
                comment,
                enable
            }
        } = promption;
        await this.NAME_FIELD.fill(name);
        await selectStoreControl.select(store);
        await giveAwayControl.select(giveAwayMethod);
        await accumulationControl.select(accumulation);
        await relationControl.select(relations);
        await this.COMMENT_TEXT.fill(comment);
        await enableControl.toggle(enable);
    }
}