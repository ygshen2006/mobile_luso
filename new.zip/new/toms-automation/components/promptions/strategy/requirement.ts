import { Page } from "@playwright/test";
import { GridComponent } from "../../common/grid";
import { ItemSelectComponent } from "../../common/controls/item.select.component";

export class PromptionStrategyRequirementComponent {
    private readonly dialog = this.page.locator(".dijitDialog:visible");

    private readonly ORDER_CONDITION_AREA = this.page.locator('.orderCondition');

    private readonly REQUIREMENT_TABLE: GridComponent = new GridComponent(this.page, this.ORDER_CONDITION_AREA);
    private selectLogicControl: ItemSelectComponent;
    private selectOrderTypeControl: ItemSelectComponent;
    constructor(public readonly page: Page) {

    }

    async selectLogic(text: string = "包含", row: number = 0) {
        const cell = await this.REQUIREMENT_TABLE.gridMain.getCellLocator(row, "andOr");
        const id = await cell.locator('input[role="textbox"]').getAttribute('id');
        this.selectLogicControl = new ItemSelectComponent(this.page, id!!);
        await this.selectLogicControl.select(text);
    }

    async selectOrderType(values: string[], row: number = 0) {
        await this.REQUIREMENT_TABLE.gridMain.clickCell(row, "label");
        const label = this.dialog.locator('label[title="值"]');

        const id = await label.getAttribute('for');
        this.selectOrderTypeControl = new ItemSelectComponent(this.page, id!!);
        await this.selectOrderTypeControl.multiSelect(values);
        await label.click();
        await this.dialog.locator('.buttonOk').click();
    }
}

