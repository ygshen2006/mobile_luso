import { Locator, Page } from "@playwright/test";

export class PromptionActionsComponent {
    private readonly SAVE_AREA = this.parentLocator.locator('div');
    private readonly SAVE_BUTTON = this.SAVE_AREA.locator(".alt-primary:has-text('保存'):visible");

    constructor(public readonly page: Page, private parentLocator: Locator) {

    }
    async clickSave(){
        await this.SAVE_BUTTON.click();
    }
}