import { Page } from "@playwright/test";
import { PromptionSearchModel } from "../../common/types/promptions/search-model";
import { ItemSelectComponent } from "../../common/controls/item.select.component";

export class PromptionPlanSearchComponent {
    private readonly PARENT = this.page.locator('.ttxBill .dijitTabPaneWrapper div[role="tabpanel"]').nth(0);
    private readonly CODE_LABEL = this.PARENT.locator('label[title="促销计划编码"]');
    private readonly NAME_LABEL = this.PARENT.locator('label[title="促销计划名称"]');
    private readonly STORE_LABEL = this.PARENT.locator('label[title="店铺"]');
    private readonly STATUS_LABEL = this.PARENT.locator('label[title="状态"]');

    constructor(public readonly page: Page) {

    }

    async inputSearch(clause: PromptionSearchModel) {
        const codeId = await this.CODE_LABEL.getAttribute('for');
        const nameId = await this.NAME_LABEL.getAttribute('for');
        const storeId = await this.STORE_LABEL.getAttribute('for');
        const statusId = await this.STATUS_LABEL.getAttribute('for');

        if (clause.code) {
            await this.PARENT.locator(`#${codeId}`).fill(clause.code);
        }
        if (clause.name) {
            await this.PARENT.locator(`#${nameId}`).fill(clause.name);
        }

        if (clause.stores && clause.stores.length > 0) {
            await new ItemSelectComponent(this.page, storeId!!).multiSelect(clause.stores);
        }
        if (clause.status) {
            await new ItemSelectComponent(this.page, statusId!!).select(clause.status);
        }
    }
}