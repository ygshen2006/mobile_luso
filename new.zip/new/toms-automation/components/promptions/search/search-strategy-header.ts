import { Page } from "@playwright/test";
import { PromptionSearchModel } from "../../common/types/promptions/search-model";
import { ItemSelectComponent } from "../../common/controls/item.select.component";

export class PromptionStrategySearchComponent {
    private readonly PARENT = this.page.locator('.queryForm');
    private readonly CODE_LABEL = this.PARENT.locator('label[title="编码"]');
    private readonly NAME_LABEL = this.PARENT.locator('label[title="名称"]');
    private readonly STORE_LABEL = this.PARENT.locator('label[title="店铺"]');
    private readonly IS_ALLOWED_LABEL = this.PARENT.locator('label[title="审核"]');

    constructor(public readonly page: Page) {

    }

    async inputSearch(clause: PromptionSearchModel) {
        const codeId = await this.CODE_LABEL.getAttribute('for');
        const nameId = await this.NAME_LABEL.getAttribute('for');
        const storeId = await this.STORE_LABEL.getAttribute('for');
        const allowedId = await this.IS_ALLOWED_LABEL.getAttribute('for');

        if (clause.code) {
            await this.PARENT.locator(`#${codeId}`).fill(clause.code);
        }
        if (clause.name) {
            await this.PARENT.locator(`#${nameId}`).fill(clause.name);
        }

        if (clause.stores && clause.stores.length > 0) {
            await new ItemSelectComponent(this.page, storeId!!).multiSelect(clause.stores);
        }
        if (clause.allowed) {
            await new ItemSelectComponent(this.page, allowedId!!).select(clause.allowed);
        }
    }
}