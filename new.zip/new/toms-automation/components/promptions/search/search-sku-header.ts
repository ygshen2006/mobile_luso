import { Locator, Page } from "@playwright/test";
import { SkuSearchModel } from "../../common/types/common/sku-search-model";

export class SearchSkuComponent {
    private readonly MAIN_AREA: Locator;

    private readonly SKU_LABEL: Locator;
    private readonly SEARCH_BUTTON: Locator;
    constructor(public readonly page: Page,
        private parentLocator: Locator,
        private skuCodeText: string = "SKU编码批量查询",
        private searchButtonText: string = "查询") {
        this.MAIN_AREA = parentLocator;
        this.SKU_LABEL = this.MAIN_AREA.locator(`label[title="${skuCodeText}"]`)
        this.SEARCH_BUTTON = this.MAIN_AREA.getByText(searchButtonText, { exact: true })
    }
    async search(skuModel: SkuSearchModel) {
        const skuCodeInputId = await this.SKU_LABEL.getAttribute('for');

        if (skuModel.codes) {
            await this.MAIN_AREA.locator(`#${skuCodeInputId}`).fill(skuModel.codes.join(','));
        }
        // todo: other fields
        await this.SEARCH_BUTTON.click();
    }
}