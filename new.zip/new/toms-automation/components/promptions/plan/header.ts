import { Page } from "@playwright/test";
import { ItemSelectComponent } from "../../common/controls/item.select.component";
import { DateTimeComponent } from "../../common/controls/date-time.component";
import { PromptionPlan } from "../../common/types/promptions/plan";

export class PromptionPlanHeaderComponent {
    private readonly HEADER_AREA = this.page.locator('.ttxBill div[role="tabpanel"]').nth(1);
    private readonly NAME_FIELD = this.HEADER_AREA.getByLabel("促销计划名称", { exact: true });
    private readonly STORE_FIELD_LABEL = this.HEADER_AREA.locator('label[title="店铺"]');

    private readonly POLIY_START_TIME = new DateTimeComponent(this.page, this.HEADER_AREA, "计划生效时间");
    private readonly POLIY_END_TIME = new DateTimeComponent(this.page, this.HEADER_AREA, "计划失效时间");

    constructor(public readonly page: Page) {

    }

    async editHeader(promption: PromptionPlan) {
        await this.createHeader(promption);
    }

    async createHeader(promptionPlan: PromptionPlan) {
        const storeId = await this.STORE_FIELD_LABEL.getAttribute("for");
        const selectStoreControl = new ItemSelectComponent(this.page, storeId!!);
        const {
            "header": {
                name,
                store,
                startDate,
                startTime,
                endDate,
                endTime
            }
        } = promptionPlan;

        await this.NAME_FIELD.fill(name);
        await selectStoreControl.select(store);
        await this.POLIY_START_TIME.input(startDate, startTime);
        await this.POLIY_END_TIME.input(endDate, endTime);
    }
}