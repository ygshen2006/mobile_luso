import { Page } from "@playwright/test";

export class ChangeCountDialog {
    private readonly dialog = this.page.locator(".dijitDialog:visible");
    constructor(public readonly page: Page) {

    }
    async changeCount(count) {
        await this.dialog.getByLabel("本次调整数量").fill(count);
        await this.dialog.getByRole('textbox', { name: '调整原因 :' }).fill("test");
        await this.dialog.getByText("确定").click();
    }
}