export enum PromptionRaisingMethod {
    DZ = '递增',
    BZ = '倍增',
    NA = '不增长'
}