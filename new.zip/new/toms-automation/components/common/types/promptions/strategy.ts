import { AndOr } from "../common/and-or"
import { YesOrNo } from "../common/yes-or-no"
import { GiveAway } from "./give-away-method"
import { PromptionSku } from "./sku"
import { STORE } from "../common/stores"

export type PromptionStrategy = {
    header: {
        name: string,
        store: STORE,
        giveAwayMethod: GiveAway,
        accumulation: YesOrNo,
        relations: AndOr,
        comment: string,
        enable: boolean
    },
    requirments: [
        {
            row: number,
            logic: string,
            values: string[]
        }
    ],
    activities: [
        {
            row: number,
            logic: string,
            count: string,
            skus: string[]
        }
    ],
    promptionSkus: PromptionSku[]
}