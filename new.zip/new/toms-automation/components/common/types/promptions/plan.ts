export type PromptionPlan = {
    header: {
        name: string,
        store: string,
        startDate: string,
        startTime?: string,
        endDate: string,
        endTime?: string
    },
    strategy: {
        name: string,
        group?: string,
        priority?: string,
        payStartDate: string,
        payStartTime: string,
        payEndDate: string,
        payEndTime: string
    }

}