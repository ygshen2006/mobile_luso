import { EnableDisable } from "../common/enable-disable"
import { YesOrNo } from "../common/yes-or-no"

export type PromptionSearchModel = {
    code?: string,
    name?: string,
    stores?: string[],
    allowed?: YesOrNo,
    status?: EnableDisable
}