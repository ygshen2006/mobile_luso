export enum PromptionProductType {
    "2-Dyson GWP" = "2-Dyson GWP",
    "3-Non-Dyson GWP" = "3-Non-Dyson GWP",
    "4-708-Free Sample" = "4-708-Free Sample",
    "8-708-goodwill" = "8-708-goodwill",
}