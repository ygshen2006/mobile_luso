export enum GiveAway {
    FIXED = "固定赠送"
}