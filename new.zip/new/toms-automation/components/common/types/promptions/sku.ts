import { PromptionProductType } from "./product-type"
import { PromptionRaisingMethod } from "./raising-method"

export type PromptionSku = {
    sku: string,
    count: string,
    raisingMethod: PromptionRaisingMethod,
    productType: PromptionProductType,
    limit?: string
}