export type SearchClause = {
    field: string,
    value: string
};