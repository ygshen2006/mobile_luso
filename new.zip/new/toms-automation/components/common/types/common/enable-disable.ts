export enum EnableDisable {
    Y = "启用",
    N = "禁用"
}