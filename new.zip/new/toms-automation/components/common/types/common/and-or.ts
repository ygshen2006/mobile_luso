export enum AndOr {
    And = "且",
    Or = "或"
}