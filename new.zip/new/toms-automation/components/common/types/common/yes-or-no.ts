export enum YesOrNo {
    Y = "是",
    N = "否"
}