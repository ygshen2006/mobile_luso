export type SkuSearchModel = {
    codes?: string[],
    name?: string,
    categories?: string[],
    models?: string[],
    productTypes?: string[],
    status?: boolean,
    onSale?: boolean
}