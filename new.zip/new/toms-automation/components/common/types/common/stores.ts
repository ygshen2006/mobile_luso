export enum STORE {
    PDD = "40 【拼多多】拼多多旗舰店"
}