import { Page } from "@playwright/test";

export class FilterSearchArea {
    private readonly searchForm = this.page.locator('#dijit_form_Form_1');
    private field;
    constructor(public readonly page: Page) { }

    async setField(fieldId, fieldValue) {
        this.field = this.searchForm.getByLabel(fieldId);
        await this.field.fill(fieldValue);
        // await
    }
}