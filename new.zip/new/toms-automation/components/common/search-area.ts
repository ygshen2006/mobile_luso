import {  Page } from "@playwright/test";

export class SearchArea {
    private readonly SEARCH_FIELD = this.page.locator("#dijit_form_FilteringSelect_0");
    private readonly DROP_LIST = this.page.locator('#widget_dijit_form_FilteringSelect_0_dropdown');

    constructor(public readonly page: Page) {

    }
    async select(item: string) {
        await this.SEARCH_FIELD.clear();
        await this.SEARCH_FIELD.type(item, { delay: 500 });
        if (await this.DROP_LIST.isVisible()) {
            await this.DROP_LIST.getByText(item, { exact: true }).click();
        }
    }
}