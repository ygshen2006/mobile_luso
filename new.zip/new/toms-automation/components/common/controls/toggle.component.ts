import { Locator, Page } from "@playwright/test";

export class ToggleComponent{
    private inputField: Locator;

    constructor(public readonly page: Page, private id: string) {
        this.inputField = page.locator(`#${id}`);
    }

    async toggle(enabled: boolean){
        if(enabled){
            await this.inputField.check();
        }else{
            await this.inputField.uncheck();
        }
    }

}