import { Locator, Page } from "@playwright/test";

export class DateTimeComponent {
    private readonly label = this.parentLocator.locator(`label[title="${this.labelText}"]`);

    constructor(public readonly page: Page, private parentLocator: Locator, private labelText: string) {
    }
    async input(date?: string, time?: string) {
        const id = await this.label.getAttribute('for');
        if (date) {
            await this.parentLocator.locator(`#${id} input[role='textbox']`).nth(0).fill(date);
        }
        if(time){
            await this.parentLocator.locator(`#${id} input[role='textbox']`).nth(1).clear({force: true});
            await this.parentLocator.locator(`#${id} input[role='textbox']`).nth(1).fill(time);
        }
    }
}