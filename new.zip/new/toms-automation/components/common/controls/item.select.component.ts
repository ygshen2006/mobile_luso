import { Locator, Page } from "@playwright/test";

export class ItemSelectComponent {
    private items: Locator;
    private inputField: Locator;

    constructor(public readonly page: Page, private id: string) {
        this.items = page.locator(`div[dijitpopupparent=${id}]`);
        this.inputField = page.locator(`#${id}`);

        // this.arrowDownButton = page.locator(`div[aria-owns='${id}_popup'] .dijitRight`);
    }
    async select(text: string) {
        await this.inputField.click({force: true});
        await this.page.keyboard.press("ArrowDown");
        await this.items.getByText(text, { exact: true }).click();
    }

    async multiSelect(texts: string[]){
        await this.inputField.click();
        await this.page.keyboard.press("ArrowDown");
        for (const text of texts) {
            await this.items.getByText(text, { exact: true }).locator('*[role="checkbox"]').check();
        }
    }
}