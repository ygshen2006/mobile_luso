import { Locator, Page } from "@playwright/test";

export class OkCancelComponent {
    private readonly PARENT: Locator;
    constructor(public readonly page: Page, private parentLocator: Locator) {
        this.PARENT = parentLocator;
    }
    async confirm(text: string = '确定') {
        await this.PARENT.getByText(text).click();
    }

    async cancel(text: string = '取消') {
        await this.PARENT.getByText(text).click();
    }
}