import { Locator, Page } from "@playwright/test";

export class GridFooterComponent {
    private readonly FOOTER = this.parentLocator.locator('.gridxFooter');
    constructor(public readonly page: Page, private parentLocator: Locator) {
    }

    async showAll() {
        await this.FOOTER.getByText('所有').click();
    }
}