import { Locator, Page } from "@playwright/test";
import { SearchClause } from "../types/common/search-clause";

export class GridMainComponent {
    private readonly MAIN = this.parentLocator.locator(".gridxMain");

    constructor(public readonly page: Page, private parentLocator: Locator) {

    }


    private datas: [] = [];
    async init() {
        this.datas = [];
        await this.page.waitForTimeout(1000);
        await this.getDatas();
    }

    async getDatas() {
        const rows = await this.MAIN.locator('.gridxBody .gridxRow .gridxRowTable').all();
        for await (const row of rows) {
            const columns = await row.locator('td').all();
            const tmp = {};
            for await (const column of columns) {
                const key = await column.getAttribute('colid');
                const value = await column.innerHTML();
                if (key) {
                    tmp[key] = value;
                }
            }
            this.datas.push(tmp);
        }
        return this.datas;
    }

    getColumnValue(rowIndex: number, columnName: string) {
        return this.datas[rowIndex][columnName];
    }

    async clickRowByIndex(rowIndex: number) {
        await this.MAIN.locator('.gridxBody .gridxRow .gridxRowTable').nth(rowIndex).click();
    }

    async clickRowBySearch(clauses: SearchClause[]) {
        let selectedRow = null;
        await this.init();

        var index = 0;
        var found = true;

        for (const _ of this.datas) {
            found = true;
            for (const clause of clauses) {
                const field = clause.field;
                const value = clause.value;
                if (_[field] !== value) {
                    found = false;
                    index++;
                    break;
                }
            }

            if (found) {
                selectedRow = _;
                break;
            }
        }

        if (found) {
            await this.clickRowByIndex(index);
        }
        return selectedRow;
    }
    async clickCell(rowIndex: number, columnName: string) {
        const row = this.MAIN.locator('.gridxBody .gridxRow .gridxRowTable').nth(rowIndex);
        const columns = await row.locator('td').all();
        for await (const column of columns) {
            const key = await column.getAttribute('colid');
            if (key === columnName) {
                await column.click();
            }
        }
    }

    async getCellLocator(rowIndex: number, columnName: string) {
        const row = this.MAIN.locator('.gridxBody .gridxRow .gridxRowTable').nth(rowIndex);
        var i = 0;
        const columns = await row.locator('td').all();
        for await (const column of columns) {
            const key = await column.getAttribute('colid');
            if (key === columnName) {
                break;
            }
            i++;
        }
        return row.locator("td").nth(i);
    }
}

