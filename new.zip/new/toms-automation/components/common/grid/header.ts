import { Locator, Page } from "@playwright/test";

export class GridHeaderComponent {
    private readonly HEDADER = this.parentLocator.locator('.gridxHeader');
    private readonly HEADER_BAR = this.HEDADER.locator('.gridxBar');
    constructor(public readonly page: Page, private parentLocator: Locator) {
    }

    async clickActionButton(text:string) {
        var searchButton = this.HEADER_BAR.getByText(text, { exact: true });
        const count = await searchButton.count();
        const visible = await searchButton.isVisible();
        if (count > 0 && !visible) {
            const id = await searchButton.getAttribute('id');
            searchButton = this.HEADER_BAR.locator(`*[aria-labelledby='${id}']`);
        }
        await searchButton.click();
    }
}