import { Locator, Page } from "@playwright/test";
import { GridHeaderComponent } from "./header";
import { GridMainComponent } from "./main";
import { GridFooterComponent } from "./footer";

export class GridComponent {
    public readonly gridHeader = new GridHeaderComponent(this.page,this.parentLocator);
    public readonly gridMain = new GridMainComponent(this.page,this.parentLocator);
    public readonly gridFooter = new GridFooterComponent(this.page,this.parentLocator);
    constructor(public readonly page: Page, private parentLocator: Locator) {
    }
}