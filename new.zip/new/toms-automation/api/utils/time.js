
const getNowTime = () => {
    return Math.floor(Date.now() / 1000);
};


const getNowTimeInString = () => {
    const now = new Date();
    return `${now.getFullYear()}${new String(now.getMonth() + 2).padStart(2, '0')}${new String(now.getDate()).padStart(2, '0')}`;
}

const getStandardNowTime = () => {
    const now = new Date();

    return `${now.getFullYear()}-${new String(now.getMonth() + 1).padStart(2, '0')}-${new String(now.getDate()).padStart(2, '0')} ${new String(now.getHours()).padStart(2, '0')}:${new String(now.getMinutes()).padStart(2, '0')}:${new String(now.getSeconds()).padStart(2, '0')}`;
}
const getStandardNowDate = (sep = "-") => {
    const now = new Date();

    return `${now.getFullYear()}${sep}${new String(now.getMonth() + 1).padStart(2, '0')}${sep}${new String(now.getDate()).padStart(2, '0')}`;
}


const generateFixedLengthNumber = (length) => {
    let result = '';
    for (let i = 0; i < length; i++) {
        result += Math.floor(Math.random() * 10); // 生成0-9之间的随机数
    }
    return result;
}

const getOrderedCode = function* (start = 0) {
    var i = start;
    while (true) {
        yield i + 1
    }
};
export { getNowTime, getNowTimeInString, getStandardNowTime, getStandardNowDate, generateFixedLengthNumber };
