import { toms } from "../../configs";

var CryptoJS = require("crypto-js");


const md5Encrypt = (data) => {
    return CryptoJS.MD5(data).toString();
};

const getSignData = (raw, uri) => {
    const sign = `${toms.encryptKey}api${uri}appKey${toms.appKey}data${raw}formatjsontimestamp${toms.timeKey}v1${toms.encryptKey}`;
    return md5Encrypt(sign).toLowerCase();
};
const encrypt = (plaintext) => {
    const key = CryptoJS.enc.Utf8.parse(toms.encryptKey);
    const jsonString = JSON.stringify(plaintext);
    var encrypted = CryptoJS.AES.encrypt(jsonString, key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });
    
    return encrypted.toString();
}

const decrypt = (raw) => {
    var key = CryptoJS.enc.Utf8.parse(toms.encryptKey);
    // Decrypt the Base64 encoded string
    var bytes = CryptoJS.AES.decrypt({ciphertext: CryptoJS.enc.Base64.parse(raw)}, key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7 // Use the same padding scheme as used for encryption
    });
    // Convert the decrypted data to a UTF-8 string
    var decryptedText = bytes.toString(CryptoJS.enc.Utf8);
    return decryptedText.trim();
};

export { getSignData, encrypt, decrypt }