const getTextRequestData = (data, url) => {
    var result = {
        'method': "POST",
        'url': url,
        'data': data,
        headers: { "Content-Type": "text/plain" }
    };
    return result;
};
export { getTextRequestData }