const STORES = {
    "PDD": "40",
    "TIKTOK": "32",
    "JD": "35",
    "WXC": "08BP0S01"
};

const RETURN_TYPE = {
    "退货": 1,
    "不退货": 0
};

const RETURN_ORDER_TYPE = {
    "库外拦截": 1,
    "退货退款": 2, // 
    "仅退款": 3
}
const PRODUCT_TYPES = {
    "FG": "1",
    "GWP": "2",
    "Non-GWP": "3",
    "ACC": "5",
    "VG": "0"
};

export { STORES, RETURN_TYPE, RETURN_ORDER_TYPE, PRODUCT_TYPES };