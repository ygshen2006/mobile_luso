import axios from "axios";
import { DataManager } from "../../data";
import { encrypt, getSignData } from "../utils/encrypt";
import { getTextRequestData } from "../utils/requestor";
import { generateFixedLengthNumber, getNowTimeInString, getStandardNowDate, getStandardNowTime } from "../utils/time";
import { PRODUCT_TYPES, STORES } from "../utils/types";
import { toms } from "../../configs";
import { CREATE_ORDER_URI } from "../utils/constants";

export class OrderManager {
    constructor() {

    }
    public async createOrder(body: OrderBody) {
        const skuArray = body.skuCodes;
        body.sourcePlatformCode = body.sourcePlatformCode || "PDD";
        const storeCode = STORES[body.sourcePlatformCode.toUpperCase()];
        const skuCollection = DataManager.getSkus().reduce((acc, value, index) => {
            acc[value.code] = value;
            return acc;
        }, {});

        skuArray.map(_ => {
            skuCollection[_.sku].count = _.count;
            skuCollection[_.sku].productType = PRODUCT_TYPES[_.productType];
        });

        const time = `${getNowTimeInString()}00${generateFixedLengthNumber(5)}`;

        const data = {
            "orderId": time,
            "storeCode": storeCode,
            "sourcePlatformCode": body.sourcePlatformCode,
            "products": skuArray.map(_ =>
                skuCollection[_.sku]
            )
        };

        const requestBody = this.getSalesOrderBody(data);
        const result = await this.sendRequest(requestBody);
        result.orderId = time;
        return result;
    }

    private async sendRequest(data){
        const body = encrypt(data);
        const sign = getSignData(body, CREATE_ORDER_URI);
        const uri = `?api=${CREATE_ORDER_URI}&appKey=${toms.appKey}&sign=${sign}&timestamp=${toms.timeKey}&v=1&format=json`;
        const options = getTextRequestData(body, `${toms.url}${uri}`);
        const response = await axios(options);
        return response.data;
    }

    private getSalesOrderBody(data) {
        const time = getStandardNowTime();
        var totalAmountWithoutTax = 0;
        var totalAmountWithTax = 0;
        const productDetails = data.products.map((_, index) => {
            totalAmountWithoutTax += _.sspPrice * _.count;
            totalAmountWithTax += _["round(sspPrice * 1.13,0)"] * _.count;

            return {
                "salesOrderDetail": {
                    "status": 100,
                    "isNonDyson": "N",
                    "skuCode": _.code,
                    "productType": _.productType,
                    "sourceLineNum": `${index + 1}`,
                    "requestQty": _.count,
                    "appointFacilityCode": "",
                    "appointLocationType": "",
                    "totalAmountWithoutTax": _.sspPrice * _.count,
                    "totalAmountWithTax": _["round(sspPrice * 1.13,0)"] * _.count,
                    "paidAmountWithoutTax": _.sspPrice * _.count,
                    "totalPayAmountDyson": _["round(sspPrice * 1.13,0)"] * _.count,
                    "discountWithoutTax": 0,
                    "totalDiscountAmountDyson": 0,
                    "taxExclusivePriceDyson": _.sspPrice,
                    "taxInclusivePriceDyson": _["round(sspPrice * 1.13,0)"],
                    "adjustAmountDyson": 0,
                    "invoiceAmountDyson": _["round(sspPrice * 1.13,0)"] * _.count,
                    "sourceSkuCodeDyson": "对应主品单号",
                    "sourceSkuBarcode": "条形码",
                    "customerSkuCode": "客户SKU编码",
                    "batchDyson": "batch0001",
                    "serialNumber": "",
                    "isCustomization": 0,
                    "customizationType": "aio订单类型",
                    "refText": "定制内容"
                }
            }
        });

        const saleHeader = {
            "salesOrderHeader": {
                "clientCode": "DYSON",
                "companyCode": "COMPANY2023010900000001",
                "sourceModifiedAt": time,
                "storeCode": `${data.storeCode}`,
                "bizChannel": "B2C",
                "sourcePlatformCode": `${data.sourcePlatformCode}`,
                "plant": "",
                "sourceOrderType": "fixed",
                "sourceOrderCode": `${data.orderId}`,
                "refOrderCodeDyson": "",
                "preSaleOrderCode": "",
                "platformOrderCode": "",
                "customizationType": "",
                "isPreSaleOrder": 0,
                "sourceUserAccount": "小小",
                "sourceUserName": "小小",
                "tradeCreatedAt": time,
                "transactionEndTime": "",
                "prePaidAmount": 0,
                "prePaidAt": "",
                "paymentStatus": 1,
                "shipToAttentionTo": "测试",
                "shipToAddress": "马当路27号",
                "shipToCountryName": "中国",
                "shipToStateName": "北京市",
                "shipToCityName": "北京市",
                "shipToDistrictName": "东城区",
                "shipToPostalCode": "432000",
                "shipToPhone": "027-12345678",
                "shipToMobile": "13100651234",
                "shipToFax": "0271-11111111",
                "shipToEmail": "yongming.qu@129.com",
                "postageAmount": 0,
                "totalAmountWithoutTax": totalAmountWithoutTax,
                "totalAmountWithTax": totalAmountWithTax,
                "orderAmountWithoutTax": totalAmountWithoutTax,
                "totalAmountDyson": totalAmountWithTax,
                "paidAmountWithoutTax": totalAmountWithoutTax,
                "totalPayAmountDyson": totalAmountWithTax,
                "discountWithoutTax": 0,
                "totalDiscountAmountDyson": 0,
                "adjustAmountDyson": 0,
                "invoiceAmountDyson": totalAmountWithTax,
                "currencyCode": "CNY",
                "invoiceRequired": 0,
                "scheduledShipOn": getStandardNowDate(),
                "estimatedProcessingTime": "",
                "invoiceType": "",
                "invoiceTitleType": "",
                "invoiceTitle": "",
                "taxpayerNo": "",
                "invocieBank": "",
                "invoiceBankAccount": "",
                "invoiceCompanyAddress": "",
                "invoiceCompanyPhone": "",
                "csStaff": "202007130624",
                "buyerNote": "卖家备注",
                "sellerNote": "卖家备注",
                "orderNote": "客服备注",
                "sourceTerminal": "门店pos机号",
                "oaid": "oaid",
                "autoRegister": "用户注册信息"
            }
        }

        const payment = [{
            "payment": {
                "payMethod": "Alipay",
                "accountNumber": "1111222233334444",
                "currency": "CNY",
                "gatewayRef": "123456789",
                "orderRef": "orderRef",
                "payRef": "payRef",
                "authRef": "authRef",
                "paidAt": time,
                "payerCompanyName": "付款人公司",
                "payerPhone": "付款人电话",
                "payerCountry": "CN",
                "payerState": "付款人省份",
                "payerCity": "付款人城市",
                "payerAddress": "付款人地址",
                "payerPostalCode": "付款人邮编",
                "payeeAccount": "支付宝账号",
                "payeeName": "支付宝姓名",
                "payAmount": totalAmountWithTax
            }
        }
        ];
        return {
            "actionMode": "NEW",
            "header": saleHeader,
            "details": productDetails,
            "payments": payment,
            "platformCode": "MALL"
        };
    };
}

export type OrderBody = {
    "skuCodes": SkuCode[],
    "sourcePlatformCode": string
}

type SkuCode = {
    "sku": string,
    "productType": string,
    "count": number
}