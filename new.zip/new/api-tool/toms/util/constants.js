const stores = {
    "PDD": "40",
    "TIKTOK": "32",
    "JD": "35",
    "WXC": "08BP0S01"
};

const RETURN_TYPE = {
    "退货": 1,
    "不退货": 0
};

const RETURN_ORDER_TYPE = {
    "库外拦截": 1,
    "退货退款": 2, // 
    "仅退款": 3
}
const PRODUCT_TYPES = {
    "FG": "1",
    "GWP": "2",
    "Non-GWP": "3",
    "ACC": "5",
    "VG": "0"
};

const FACILITIES = ["8951", "8952"];
const POSITIONS = ["1000"];

const CREATE_ORDER_URI = "ofs.salesOrder.create";
const SEARCH_ORDER_URI = "ofs.salesOrder.search";
const SALE_ORDER_STATUS_URI = "ofs.salesOrder.statusSearch";
const SALES_SHIP_CONFIRM_URI = "ofs.shipment.confirm";
const SALES_CONFIRM_ORDER_URI = "/api/edi/csrm/in/order_confirm";
const SALES_STATUS_UPDATE_URI = "/api/edi/csrm/in/order_state";

const ERP_UPLOAD_URI = "erpDomain"
const RETURN_PRODUCT_CREATE_URI = "ofs.returnOrder.create";
const RETURN_ORDER_SEARCH_URI = "ofs.returnOrder.search";

const ORDER_TYPES = {
    "ZRPL": "退货:退货退款/仅退款"
}
module.exports = {
    PRODUCT_TYPES,
    FACILITIES,
    POSITIONS,
    ORDER_TYPES,
    stores, RETURN_TYPE, RETURN_ORDER_TYPE, RETURN_ORDER_SEARCH_URI,
    CREATE_ORDER_URI, SEARCH_ORDER_URI, SALE_ORDER_STATUS_URI, SALES_SHIP_CONFIRM_URI, SALES_CONFIRM_ORDER_URI, SALES_STATUS_UPDATE_URI, RETURN_PRODUCT_CREATE_URI
}