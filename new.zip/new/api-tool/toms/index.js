const { toms } = require("../config/configs");
const { getTextRequestData } = require("../utils/requestor");
const { getStandardNowTime, getStandardNowDate, generateFixedLengthNumber, getNowTimeInString } = require("../utils/time");
const { encrypt, getSignData, decrypt } = require("./util/encrypt");
const axios = require('axios');
const fs = require("fs");
const _l = require("lodash");
const skus = require("./data/skus.json").filter(_ => _.sspPrice != undefined);
const { CREATE_ORDER_URI, SEARCH_ORDER_URI, SALE_ORDER_STATUS_URI, SALES_SHIP_CONFIRM_URI, SALES_CONFIRM_ORDER_URI, SALES_STATUS_UPDATE_URI, RETURN_PRODUCT_CREATE_URI, FACILITIES, POSITIONS } = require("./util/constants");
const fs2 = require("fs").promises;

const createOrder = async (data) => {
    const body = encrypt(data, toms.encryptKey);
    const sign = getSignData(body, CREATE_ORDER_URI);
    const uri = `?api=${CREATE_ORDER_URI}&appKey=${toms.appKey}&sign=${sign}&timestamp=${toms.timeKey}&v=1&format=json`;
    const options = getTextRequestData(body, `${toms.url}${uri}`);
    const response = await axios(options);
    return response.data;
};

const getOrders = async (orders, storeCode, searchPath = SEARCH_ORDER_URI) => {
    const requestBody = {
        "clientCode": "DYSON",
        "bizChannel": "B2C",
        "sourceOrderCodes": orders,
        "storeCode": storeCode,
        "companyCode": "1",
        "pageNo": 1,
        "pageSize": 50
        // "created_start":"2024-05-18 00:09:26",
        // "created_end":"2024-05-18 22:09:26",
    };

    const body = encrypt(requestBody, toms.encryptKey);
    const sign = getSignData(body, searchPath);
    const uri = `?api=${searchPath}&appKey=${toms.appKey}&sign=${sign}&timestamp=${toms.timeKey}&v=1&format=json`;;

    const options = getTextRequestData(body, `${toms.url}${uri}`);
    const response = await axios(options);
    const decrypted = decrypt(response.data.data);
    response.data.data = decrypted;
    return response.data;
};

const getOrderStatus = async (orders, storeCode) => {
    const requestBody = {
        "clientCode": "DYSON",
        "bizChannel": "B2C",
        "sourceOrderCodes": orders,
        "storeCode": storeCode,
        "companyCode": "1",
        "pageNo": 1,
        "pageSize": 50
    };

    const body = encrypt(requestBody, toms.encryptKey);
    const sign = getSignData(body, SALE_ORDER_STATUS_URI);
    const uri = `?api=${SALE_ORDER_STATUS_URI}&appKey=${toms.appKey}&sign=${sign}&timestamp=${toms.timeKey}&v=1&format=json`;;

    const options = getTextRequestData(body, `${toms.url}${uri}`);
    const response = await axios(options);
    const decrypted = decrypt(response.data.data);
    response.data.data = decrypted;
    return response.data;
};

const confirmOrder = async (order, csrmNo, orderType) => {
    const body = {
        "data_exchange_id": `D20240129010749b8bfb06d46cccf3${generateFixedLengthNumber(13)}`,
        "purchase_order_number": order,
        "csrm_order_number": csrmNo,
        "sap_order_number": "",
        "order_type": orderType
    };
    const options = getTextRequestData(body, `${toms.domain}${SALES_CONFIRM_ORDER_URI}`);
    const response = await axios(options);
    return response.data;
};


const updateOrderStatus = async (orderId, csrmOrderId, orderType, delivery_number, tracking_ref, order_lines, courier = "SF") => {
    const delivery = {
        "delivery_number": delivery_number,
        "delivery_date": getStandardNowDate('/'),
        "tracking_ref": tracking_ref,
        "courier": courier,
        "rescheduled": "CSRM"
    };

    const body = {
        "data_exchange_id": `10000414cf41c5e4ed44a19c8${generateFixedLengthNumber(13)}`,
        "delivery": delivery,
        "order": {
            "purchase_order_number": orderId,
            "order_number": csrmOrderId,
            "sap_order_number": "",
            "order_type": orderType,
            "confirmed": "X",
            "on_pick": "X",
            "picked": "X",
            "despatched": "X",
            "cancelled": "",
            "received": "",
            "on_refund": "",
            "refunded": "",
            "order_line": order_lines
        }
    };

    const options = getTextRequestData(body, `${toms.domain}${SALES_STATUS_UPDATE_URI}`);
    const response = await axios(options);
    const responseData = response.data;
    responseData.delivery = {
        "outBizCode": delivery_number,
        "carrierCode": courier,
        "waybillCode": tracking_ref,
        "shipAt": delivery.delivery_date.replace(/\//g, '-'),
        "consignType": ""
    };

    return responseData;
};

const updateReturnOrderStatus = async (retOrder, orderType, delivery_number, tracking_ref, order_lines, courier = "SF") => {
    const body = {
        "data_exchange_id": `10000414cf41c5e4ed44a19c8${generateFixedLengthNumber(13)}`,
        "delivery": {
            "delivery_number": delivery_number,
            "delivery_date": getStandardNowDate('/'),
            "tracking_ref": tracking_ref,
            "courier": courier,
            "rescheduled": "CSRM"
        },
        "order": {
            "purchase_order_number": retOrder,
            "order_number": retOrder,
            "sap_order_number": "",
            "order_type": orderType,
            "confirmed": "X",
            "on_pick": "X",
            "picked": "X",
            "despatched": "X",
            "cancelled": "",
            "received": "",
            "on_refund": "",
            "refunded": "",
            "order_line": order_lines
        }
    };
    const options = getTextRequestData(body, `${toms.domain}${SALES_STATUS_UPDATE_URI}`);
    const response = await axios(options);
    return response.data;
};


const createReturnOrder = async (order, returnType, orderType, returnCode, shipCode, retStatus) => {
    const orderId = order['header']['sourceOrderCode'];
    const sourcePlatformCode = order['header']['sourcePlatformCode'];
    const nowTime = getStandardNowTime();
    const totalAmountWithTax = order['header']['totalAmountWithTax'];
    const storeCode = order['header']['storeCode'];
    const products = order['details'].map(_ => {
        return {
            "skuCode": _.skuCode,
            "skuName": "",
            "facilityCode": "",
            "locationType": "",
            "isNonDyson": "N",
            "companyCode": "1",
            "clientCode": "DYSON",
            "storeCode": storeCode,
            "returnType": returnType,
            "refundInd": 1,
            "requestQty": _.requestQty,
            "quantityUM": "EA",
            "msrPrice": "",
            "totalAmountDyson": _.totalPayAmountDyson,
            "actualRefundAmountDyson": _.totalPayAmountDyson, // 这个字段不确定有折扣会不会 有问题，遇到问题再检查
            "sourceLineNum": _.sourceLineNum,
            "sourceOrderCode": orderId,
            "sourceDiscountPrice": "",
            "sourcePayAmount": "",
            "sourceRequestQty": _.requestQty,
            "bomType": 1,
            "reasonCode": "",
            "reasonDesc": ""
        }
    });

    const data = {
        "header": {
            "returnType": returnType, // 1 退货， 0 不退货
            "exchangeType": 0,
            "refundInd": 1,
            "orderType": orderType, // 1 库外拦截， 2 退货退款 3. 仅退款
            "bizChannel": "B2C",
            "companyCode": "1",
            "clientCode": "DYSON",
            "storeCode": storeCode,
            "sourceUserAccount": "",
            "sourceUserName": "",
            "dysonOrderType": "",
            "sourcePlatformCode": sourcePlatformCode,
            "sourceOrderCode": orderId,
            "sourceOrderStatusWhenReturned": "RADE_BUYER_SIGNED",
            "sourceReturnCode": returnCode,
            "sourceReturnStatus": retStatus, // WAIT_SELLER_AGREE 不退款， SUCCESS 已退款
            "sourceCreatedAt": nowTime,
            "sourceModifiedAt": nowTime,
            "reasonCode": "7天无理由退货",
            "rejectReason": "",
            "returnNote": "",
            "sellerNote": "",
            "requestRefundAmountDyson": totalAmountWithTax, //totalAmountWithTax
            "actualRefundAmountDyson": totalAmountWithTax,
            "totalQty": 2, //
            "shipFromAttentionTo": "",
            "shipFromAddress": "",
            "shipFromCountry": "",
            "shipFromState": "",
            "shipFromCity": "",
            "shipFromDistrict": "",
            "shipFromPostalCode": "",
            "shipFromPhone": "",
            "shipFromMobile": "",
            "shipFromFax": "",
            "shipFromEmail": "",
            "shipCarrier": "",
            "shipWaybillCode": "",
            "shipLogisticsStatus": "",
            "returnCarrier": "SF",
            "returnWaybillCode": shipCode, //
            "returnLogisticsStatus": "",
            "payAccount": "",
            "payOrderNo": "",
            "refundThru": "ALIPAY",
            "csStuff": "",
            "refundedAt": ""
        },
        "details": products,
        "actionMode": "NEW",
        "platformCode": "MALL"
    };
    
    const newData={
        "header": {
            "returnType": 1,
            "exchangeType": 0,
            "refundInd": 1,
            "orderType": 2,
            "bizChannel": "B2C",
            "companyCode": "1",
            "clientCode": "DYSON",
            "storeCode": "40",
            "sourceUserAccount": "",
            "sourceUserName": "",
            "dysonOrderType": "",
            "sourcePlatformCode": "PDD",
            "sourceOrderCode": "202407260000922",
            "sourceOrderStatusWhenReturned": "RADE_BUYER_SIGNED",
            "sourceReturnCode": "2024072647951",
            "sourceReturnStatus": "SUCCESS",
            "sourceCreatedAt": "2024-06-26 16:49:46",
            "sourceModifiedAt": "2024-06-26 16:49:46",
            "reasonCode": "7天无理由退货",
            "rejectReason": "",
            "returnNote": "",
            "sellerNote": "",
            "requestRefundAmountDyson": 3390,
            "actualRefundAmountDyson": 3390,
            "totalQty": 1,
            "shipFromAttentionTo": "",
            "shipFromAddress": "",
            "shipFromCountry": "",
            "shipFromState": "",
            "shipFromCity": "",
            "shipFromDistrict": "",
            "shipFromPostalCode": "",
            "shipFromPhone": "",
            "shipFromMobile": "",
            "shipFromFax": "",
            "shipFromEmail": "",
            "shipCarrier": "",
            "shipWaybillCode": "",
            "shipLogisticsStatus": "",
            "returnCarrier": "SF",
            "returnWaybillCode": "SF7896957749",
            "returnLogisticsStatus": "",
            "payAccount": "",
            "payOrderNo": "",
            "refundThru": "ALIPAY",
            "csStuff": "",
            "refundedAt": ""
        },
        "details": [
            {
                "skuCode": "473817-01",
                "skuName": "",
                "facilityCode": "",
                "locationType": "",
                "isNonDyson": "N",
                "companyCode": "1",
                "clientCode": "DYSON",
                "storeCode": "40",
                "returnType": 1,
                "refundInd": 1,
                "requestQty": 1,
                "quantityUM": "EA",
                "msrPrice": "",
                "totalAmountDyson": 3390,
                "actualRefundAmountDyson": 3390,
                "sourceLineNum": "1",
                "sourceOrderCode": "202407260000922",
                "sourceDiscountPrice": "",
                "sourcePayAmount": "",
                "sourceRequestQty": 1,
                "bomType": 1,
                "reasonCode": "",
                "reasonDesc": ""
            }
        ],
        "actionMode": "NEW",
        "platformCode": "MALL"
    };
    const body = encrypt(newData, toms.encryptKey);
    const sign = getSignData(body, RETURN_PRODUCT_CREATE_URI);
    const uri = `?api=${RETURN_PRODUCT_CREATE_URI}&appKey=${toms.appKey}&sign=${sign}&timestamp=${toms.timeKey}&v=1&format=json`;
    const options = getTextRequestData(body, `${toms.url}${uri}`);
    const response = await axios(options);
    return response.data;
};
// const confirmReturn =    
const readStores = () => {
    const path = `${__dirname}\\data\\stores.json`;
    return fs.readFileSync(path, { encoding: "utf-8" });
};
// const example ={
//     "q":[{
//         "facilityCode": "8952",
//         "position": "1000",
//         "count": true // 个数大于0
//     }, {
//         "facilityCode": "8951",
//         "position": "1000",
//         "count": false // 个数小于0
//     }],
// };
const readSkuOfInventory = async (data) => {
    const path = `${__dirname}\\data\\inventory.json`;
    const result = await fs2.readFile(path, { encoding: "utf-8" });
    const jsonData = JSON.parse(result);
    const returnedData = [];
    // filter availables only
    const mapBySku = _l.groupBy(jsonData.filter(_ => _.inventorySts === "AVAILABLE"), "skuCode");
    _l.forEach(mapBySku, (value, key) => {
        const s = [];
        _l.forEach(data.q, (v) => {
            const facilityCode = v.facilityCode;
            const position = v.position;
            const category = v.category;
            const count = v.count;
            if (count) {
                const has = value.find(_ => _.facilityCode === facilityCode && _.attribute1 === position && _.skuCategory === category && _.availableQty > 0);
                s.push(has !== undefined)
            } else {
                const newValue = value.filter(_ => _.skuCategory === category);
                if (newValue.length == 0) {
                    s.push(false);
                } else {
                    const hasCount = newValue.find(_ => _.facilityCode === facilityCode && _.attribute1 === position && _.availableQty <= 0);
                    const hasRecord = newValue.find(_ => _.facilityCode === facilityCode && _.attribute1 === position);
                    s.push(hasCount || !hasRecord);
                }
            }
        });

        if (s.indexOf(false) == -1) {
            returnedData.push(key);
        }
    });

    const skuKeys = skus.map(_ => _.code);
    return returnedData.filter(_ => skuKeys.indexOf(_) != -1);
};
const readSkuOfInventoryIgnoreCount = async (data) => {
    const path = `${__dirname}\\data\\inventory.json`;
    const result = await fs2.readFile(path, { encoding: "utf-8" });
    const jsonData = JSON.parse(result);
    const returnedData = [];
    // filter availables only
    const mapBySku = _l.groupBy(jsonData.filter(_ => _.inventorySts === "AVAILABLE"), "skuCode");
    _l.forEach(mapBySku, (value, key) => {
        const s = [];
        _l.forEach(data.q, (v) => {
            const facilityCode = v.facilityCode;
            const position = v.position;
            const category = v.category;
            const count = v.count;
            if (count) {
                const has = value.find(_ => _.facilityCode === facilityCode && _.attribute1 === position && _.skuCategory === category);
                s.push(has !== undefined)
            } else {
                const newValue = value.filter(_ => _.skuCategory === category);
                if (newValue.length == 0) {
                    s.push(false);
                } else {
                    const hasRecord = newValue.find(_ => _.facilityCode === facilityCode && _.attribute1 === position);
                    s.push(!hasRecord);
                }
            }
        });

        if (s.indexOf(false) == -1) {
            returnedData.push(key);
        }
    });

    const skuKeys = skus.map(_ => _.code);
    return returnedData.filter(_ => skuKeys.indexOf(_) != -1);
};
const getSalesOrderBody = (data) => {
    const time = getStandardNowTime();
    var totalAmountWithoutTax = 0;
    var totalAmountWithTax = 0;
    var totalDiscount = 0;
    var totalInvoiceDiscount = 0;
    const productDetails = data.products.map((_, index) => {
        const invoiceDiscount = _.invoiceDiscount;
        totalInvoiceDiscount += invoiceDiscount;
        totalAmountWithoutTax += _.sspPrice * _.count;
        const discount = _["round(sspPrice * 1.13,0)"] * _.count * (_.discount / 100);

        totalAmountWithTax += (_["round(sspPrice * 1.13,0)"] * _.count - discount );
        totalDiscount += discount;
        return {
            "salesOrderDetail": {
                "status": 100,
                "isNonDyson": "N",
                "skuCode": _.code,
                "productType": _.productType,
                "sourceLineNum": `${index + 1}`,
                "requestQty": _.count,
                "appointFacilityCode": "",
                "appointLocationType": "",
                "totalAmountWithoutTax": _.sspPrice * _.count,
                "totalAmountWithTax": _["round(sspPrice * 1.13,0)"] * _.count,
                "paidAmountWithoutTax": _.sspPrice * _.count,
                "totalPayAmountDyson": _["round(sspPrice * 1.13,0)"] * _.count - discount,
                "discountWithoutTax": 0,
                "totalDiscountAmountDyson": discount,
                "taxExclusivePriceDyson": _.sspPrice,
                "taxInclusivePriceDyson": _["round(sspPrice * 1.13,0)"],
                "adjustAmountDyson": 0,
                "invoiceAmountDyson": _["round(sspPrice * 1.13,0)"] * _.count - discount - invoiceDiscount,
                "sourceSkuCodeDyson": "对应主品单号",
                "sourceSkuBarcode": "条形码",
                "customerSkuCode": "客户SKU编码",
                "batchDyson": "batch0001",
                "serialNumber": "",
                "isCustomization": 0,
                "customizationType": "aio订单类型",
                "refText": "定制内容"
            }
        }
    });

    const saleHeader = {
        "salesOrderHeader": {
            "clientCode": "DYSON",
            "companyCode": "COMPANY2023010900000001",
            "sourceModifiedAt": time,
            "storeCode": `${data.storeCode}`,
            "bizChannel": "B2C",
            "sourcePlatformCode": `${data.sourcePlatformCode}`,
            "plant": "",
            "sourceOrderType": "fixed",
            "sourceOrderCode": `${data.orderId}`,
            "refOrderCodeDyson": "",
            "preSaleOrderCode": "",
            "platformOrderCode": "",
            "customizationType": "",
            "isPreSaleOrder": 0,
            "sourceUserAccount": "小小",
            "sourceUserName": "小小",
            "tradeCreatedAt": time,
            "transactionEndTime": "",
            "prePaidAmount": 0,
            "prePaidAt": "",
            "paymentStatus": 1,
            "shipToAttentionTo": "测试",
            "shipToAddress": "马当路27号",
            "shipToCountryName": "中国",
            "shipToStateName": "北京市",
            "shipToCityName": "北京市",
            "shipToDistrictName": "东城区",
            "shipToPostalCode": "432000",
            "shipToPhone": "027-12345678",
            "shipToMobile": "13100651234",
            "shipToFax": "0271-11111111",
            "shipToEmail": "yongming.qu@129.com",
            "postageAmount": 0,
            "totalAmountWithoutTax": totalAmountWithoutTax,
            "totalAmountWithTax": totalAmountWithTax,
            "orderAmountWithoutTax": totalAmountWithoutTax,
            "totalAmountDyson": totalAmountWithTax,
            "paidAmountWithoutTax": totalAmountWithoutTax,
            "totalPayAmountDyson": totalAmountWithTax,
            "discountWithoutTax": 0,
            "totalDiscountAmountDyson": totalDiscount,
            "adjustAmountDyson": 0,
            "invoiceAmountDyson": totalAmountWithTax-totalInvoiceDiscount,
            "currencyCode": "CNY",
            "invoiceRequired": 0,
            "scheduledShipOn": getStandardNowDate(),
            "estimatedProcessingTime": "",
            "invoiceType": "",
            "invoiceTitleType": "",
            "invoiceTitle": "",
            "taxpayerNo": "",
            "invocieBank": "",
            "invoiceBankAccount": "",
            "invoiceCompanyAddress": "",
            "invoiceCompanyPhone": "",
            "csStaff": "202007130624",
            "buyerNote": "卖家备注",
            "sellerNote": "卖家备注",
            "orderNote": "客服备注",
            "sourceTerminal": "门店pos机号",
            "oaid": "oaid",
            "autoRegister": "用户注册信息"
        }
    }

    const payment = [{
        "payment": {
            "payMethod": "Alipay",
            "accountNumber": "1111222233334444",
            "currency": "CNY",
            "gatewayRef": "123456789",
            "orderRef": "orderRef",
            "payRef": "payRef",
            "authRef": "authRef",
            "paidAt": time,
            "payerCompanyName": "付款人公司",
            "payerPhone": "付款人电话",
            "payerCountry": "CN",
            "payerState": "付款人省份",
            "payerCity": "付款人城市",
            "payerAddress": "付款人地址",
            "payerPostalCode": "付款人邮编",
            "payeeAccount": "支付宝账号",
            "payeeName": "支付宝姓名",
            "payAmount": totalAmountWithTax
        }
    }
    ];
    return {
        "actionMode": "NEW",
        "header": saleHeader,
        "details": productDetails,
        "payments": payment,
        "platformCode": "MALL"
    };
};

const uploadSaleToERP = async (order, delivery, sapOrderCode) => {
    const orderHeader = order.header;
    const orderDetails = order.details;
    const details = orderDetails.map(_ => {
        return {
            "sourceLineNum": _.sourceLineNum,
            "skuCode": _.skuCode,
            "serialNumber": _.serialNumber || "",
            "batch": "XXXX",
            "shipQty": _.shipQty
        };
    });

    const source = {
        "header": {
            "sourceOrderCode": orderHeader.sourceOrderCode,
            "platformOrderCode": orderHeader.platformOrderCode,
            "csrmOrderNumber": orderHeader.csrmOrderNumber,
            "sapOrderNumber": sapOrderCode
        },
        "containers": [{
            "header": {
                "shippingcontainerHeader": { ...delivery, sourceOrderCode: orderHeader.sourceOrderCode }
            },
            "details": [{
                "shippingcontainerDetails": details
            }]
        }]
    };

    const body = encrypt(source, toms.encryptKey);
    const sign = getSignData(body, SALES_SHIP_CONFIRM_URI);
    const uri = `?api=${SALES_SHIP_CONFIRM_URI}&appKey=${toms.appKey}&sign=${sign}&timestamp=${toms.timeKey}&v=1&format=json`;;

    const options = getTextRequestData(body, `${toms.url}${uri}`);
    const response = await axios(options);
    const decrypted = decrypt(response.data.data);
    response.data.data = decrypted;
};

const uploadReturnToERP = () => {

};

module.exports = { uploadSaleToERP, uploadReturnToERP, readSkuOfInventoryIgnoreCount, createReturnOrder, getSalesOrderBody, getOrders, getOrderStatus, confirmOrder, updateOrderStatus, updateReturnOrderStatus, createOrder, readStores, readSkuOfInventory }