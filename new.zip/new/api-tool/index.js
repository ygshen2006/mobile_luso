const express = require('express');
const skus = require("./toms/data/skus.json").filter(_ => _.sspPrice != undefined);
const { callOmsWms } = require('./oms');
const { appServer } = require('./config/configs');
const { createOrder, readStores, readSku, getSalesOrderBody, getOrders, getOrderStatus, confirmOrder, updateOrderStatus, readSkuOfInventory, readSkuOfInventoryIgnoreCount, createReturnOrder, updateReturnOrderStatus, uploadSaleToERP } = require('./toms');
const { getNowTimeInString, generateFixedLengthNumber } = require('./utils/time');
const Counter = require('./utils/counter');
const { decrypt } = require('./oms/util/encrypt');
const { stores, RETURN_TYPE, RETURN_ORDER_TYPE, PRODUCT_TYPES } = require('./toms/util/constants');
const { RETURN_ORDER_SEARCH_URI } = require('./toms/util/constants');
const app = express();
app.use(express.json());
const axios = require('axios');
// OMS
app.get('/api/data', async (req, res) => {
    const data = {
        "Update_flag": "1",
        "GUID": "DBA82F10-ED10-1CF8-650C-60A6B24DDCB0",
        "OTC": "O89WEB01"
    };
    const result = await callOmsWms(data);
    res.write(decrypt(result.data));
    res.end();
});

const inventories = {};
// Read SKU
app.post('/api/toms/skus/byCount', async (req, res) => {
    const body = req.body;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(await readSkuOfInventory(body)));
});
app.post('/api/toms/skus/byFacilityCode', async (req, res) => {
    const body = req.body;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(await readSkuOfInventoryIgnoreCount(body)));
});

var skuCollection = {};
app.post('/api/toms/createOrder', async (req, res) => {
    const requestData = req.body;
    const platform = requestData.sourcePlatformCode || "PDD";
    const storeCode = stores[platform.toUpperCase()];

    const skuArray = requestData.skuCodes;
    skuCollection = skus.reduce((acc, value, index) => {
        acc[value.code] = value;
        return acc;
    }, {});

    skuArray.map(_ => {
        skuCollection[_.sku].count = _.count;
        skuCollection[_.sku].productType = PRODUCT_TYPES[_.productType];
        skuCollection[_.sku].discount = _.discount | 0;
        skuCollection[_.sku].invoiceDiscount = _.invoiceDiscount | 0;
    });

    // const time = `${getNowTimeInString()}00${Counter.increase()}`;
    const time = `${getNowTimeInString()}00${generateFixedLengthNumber(5)}`;

    const data = {
        "orderId": time,
        "storeCode": storeCode,
        "sourcePlatformCode": platform,
        "products": skuArray.map(_ =>
            skuCollection[_.sku]
        )
    };
    const body = getSalesOrderBody(data);

    const result = await createOrder(body);
    result['orderId'] = time;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});

app.post("/api/toms/getOrders", async (req, res) => {
    const requestData = req.body;
    const orders = requestData['orders'];
    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";

    const result = await getOrders(orders, stores[sourcePlatformCode]);
    res.setHeader('Content-Type', "application/json");
    res.end(result.data);
});

app.post("/api/toms/getOrderStatus", async (req, res) => {
    const requestData = req.body;
    const orders = requestData['orders'];
    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";

    const result = await getOrderStatus(orders, stores[sourcePlatformCode]);
    res.setHeader('Content-Type', "application/json");
    res.end(result.data);
});

app.post("/api/toms/orderConfirm", async (req, res) => {
    const requestData = req.body;
    const order = requestData['order'];
    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";

    // call getOrder to fetch csrm
    const orderDetail = await getOrders([order], stores[sourcePlatformCode]);
    const origin = JSON.parse(orderDetail.data)[0];
    const csrmCode = origin.header.csrmOrderNumber;
    const orderType = origin.header.orderType;
    const result = await confirmOrder(order, csrmCode, orderType);
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});
app.post("/api/toms/orderState", async (req, res) => {
    const requestData = req.body;
    const order = requestData['order'];
    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";
    const deliveryNumber = `${generateFixedLengthNumber(10)}`;
    const trackNumber = `SF${deliveryNumber}`;

    const orderDetail = await getOrders([order], stores[sourcePlatformCode]);
    const origin = JSON.parse(orderDetail.data)[0];
    const csrmCode = origin.header.csrmOrderNumber;
    const orderType = origin.header.orderType;
    const products = origin.details;

    const orderLines = products.map(_ => {
        return {
            "line_number": _.sourceLineNum,
            "part_number": _.skuCode,
            "confirmed": "X",
            "on_pick": "X",
            "picked": "X",
            "despatched": "X",
            "cancelled": "",
            "received": "",
            "on_refund": "",
            "refunded": "",
            "serial_numbers": [
                {
                    "serial_number": `C6D-CN-AAA${generateFixedLengthNumber(4)}A`
                }
            ],
            "batch_codes": {
                "batch_code": [
                    {
                        "quantity": `${_.requestQty}`,
                        "code": "	"
                    }
                ]
            }
        }
    });

    // call getOrder to fetch csrm
    const result = await updateOrderStatus(order, csrmCode, orderType, deliveryNumber, trackNumber, orderLines);
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});

// 销售订单回传上位ERP
app.post("/api/toms/sales/erp", async (req, res) => {
    const requestData = req.body;
    const order = requestData['order'];
    const delivery = requestData['delivery'];
    const sapOrderCode = requestData['sapOrderNumber'];

    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";

    const orderDetail = await getOrders([order], stores[sourcePlatformCode]);
    const origin = JSON.parse(orderDetail.data)[0];
    // call getOrder to fetch csrm
    const result = await uploadSaleToERP(origin, delivery, sapOrderCode);
    // result['tracking_ref'] = trackNumber;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});

// 新建退款单
app.post("/api/toms/returnOrder", async (req, res) => {
    const requestData = req.body;
    const orderId = requestData['order'];
    const returnType = RETURN_TYPE[requestData['returnType']];
    const orderType = RETURN_ORDER_TYPE[requestData['returnOrderType']];
    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";
    const retStatus = requestData['retStatus'] || "WAIT_SELLER_AGREE";
    const orders = await getOrders([orderId], stores[sourcePlatformCode]);
    // call getOrder to fetch csrm
    // console.log(orders)
    const returnCode = `${getNowTimeInString()}${generateFixedLengthNumber(5)}`;
    const shipCode = `SF${generateFixedLengthNumber(10)}`;

    const result = await createReturnOrder(JSON.parse(orders.data)[0], returnType, orderType, returnCode, shipCode, retStatus);
    // console.log(result)
    result['returnOrderId'] = returnCode;
    result['shipCode'] = shipCode;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});

app.post("/api/toms/return/orderConfirm", async (req, res) => {
    const requestData = req.body;
    const order = requestData['order'];
    /* "returnType":"退货",
     "returnOrderType":"退货退款"   
     orderType=ZRPL
    */
    // You need to get the data from CSRM
    const orderType = requestData['order_type'] || "ZRPL"; // depends on what is the type of the return order
    const csrmCode = requestData['csrmNumber'];

    const result = await confirmOrder(order, csrmCode, orderType);
    result.csrmNumber = csrmCode;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});
app.post("/api/toms/return/orderState", async (req, res) => {
    const requestData = req.body;
    const order = requestData['sourceOrder'];
    const retOrder = requestData['retOrder'];
    const sourcePlatformCode = requestData['sourcePlatformCode'] || "PDD";
    const deliveryNumber = `${generateFixedLengthNumber(10)}`;
    const trackNumber = requestData['trackingRef'];

    const orderDetail = await getOrders([order], stores[sourcePlatformCode]);
    const origin = JSON.parse(orderDetail.data)[0];
    const orderType = requestData['order_type'] || "ZRPL";
    const products = origin.details;

    const orderLines = products.map(_ => {
        return {
            "line_number": _.sourceLineNum,
            "part_number": _.skuCode,
            "confirmed": "X",
            "on_pick": "X",
            "picked": "X",
            "despatched": "X",
            "cancelled": "",
            "received": "",
            "on_refund": "",
            "refunded": "",
            "serial_numbers": [
                {
                    "serial_number": _.serialNumber
                }
            ],
            "batch_codes": {
                "batch_code": [
                    {
                        "quantity": `${_.requestQty}`,
                        "code": "	"
                    }
                ]
            }
        }
    });

    // call getOrder to fetch csrm
    const result = await updateReturnOrderStatus(retOrder, orderType, deliveryNumber, trackNumber, orderLines);
    result['tracking_ref'] = trackNumber;
    res.setHeader('Content-Type', "application/json");
    res.end(JSON.stringify(result));
});

// TOMS
app.get('/api/toms', async (req, res) => {


    const result = await createOrder(data);

    res.write(JSON.stringify(result));
    res.end();
});

app.get('/api/test', async (req, res) => {
    res.cookie("test","va");

    var qs = require('qs');
    var data = qs.stringify({
        'x': 'xSuu/Q3zNWSOFarOpXjeNA==',
        'y': 'iJ+gJH07GyMQMSkd/XyjSw=='
    });
    var config = {
        method: 'post',
        url: 'https://cncsrmsit.dyson.cn/test-api/auth/oauth/login',
        headers: {
            'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        proxy: {
            protocol: 'http',
            host: 'cn-sh-psg-01.dyson.global.corp',
            port: 8080
        },
        data: data
    };

    axios(config)
        .then(function (response) {
            console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
            console.log(error);
        });

        res.end("test");
})
const { port } = appServer;
// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});