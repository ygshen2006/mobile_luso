const { oms } = require('../config/configs');
const { getNowTime } = require('../utils/time');
const { getSignData } = require('./util/encrypt');
const { getFormRequestData } = require('../utils/requestor');
const nowTime = getNowTime();
const axios = require('axios');

// Create a custom HTTPS agent with specific TLS settings
const callOmsWms = async (data)=>{
    const uri = `?act=order_info&appkey=${oms.appKey}&time=${nowTime}&sign=${getSignData(data, nowTime)}`;
    const options = getFormRequestData(data,`${oms.url}${uri}`);
    const response = await axios(options);
    return response.data;
};

module.exports = {callOmsWms}