var CryptoJS = require("crypto-js");

const { oms } = require("../../config/configs");

const md5Encrypt = (data) => {
    return CryptoJS.MD5(data).toString();
};

const getSignData = (raw, nowTime) => {
    const firstMD5 = md5Encrypt(JSON.stringify(raw)).toLowerCase();
    return md5Encrypt(`${firstMD5}${oms.appSecrect}${nowTime}`).toLowerCase();
};

const decrypt = (raw) => {
    // Decode base64
    const data = CryptoJS.enc.Base64.parse(raw).toString(CryptoJS.enc.Utf8);
    // Encryption key
    var key = CryptoJS.enc.Utf8.parse(oms.aesKey);
    // Decrypt the Base64 encoded string
    var decrypted = CryptoJS.AES.decrypt(data, key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7 // Use the same padding scheme as used for encryption
    });
    // Convert the decrypted data to a UTF-8 string
    var decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
    return decryptedText;
};

module.exports = {getSignData, decrypt}