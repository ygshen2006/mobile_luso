const config = require('config');
const proxy = config.get("proxy");
const appServer = config.get("server");

const oms = {
    url: config.get("oms").url,
    appSecrect: config.get("oms").appSecrect,
    appKey: config.get("oms").appKey,
    aesKey: config.get("oms").aesKey
};
const toms = {
    erpDomain: config.get("toms").erpDomain,
    domain: config.get("toms").domain,
    url: config.get("toms").url,
    encryptKey: config.get("toms").encryptKey,
    appKey: config.get("toms").appKey,
    timeKey: config.get("toms").timeKey,
    createOrderUri: config.get("toms").createOrderUri
}
module.exports = { oms, proxy, appServer, toms }