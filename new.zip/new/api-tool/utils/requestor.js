var FormData = require('form-data');
const getFormRequestData = (data, url) => {
    var payload = new FormData();

    for (let key in data) {
        payload.append(key, data[key]);
    }
    var result = {
        'method': "POST",
        'url': url,
        'data': payload,
        headers: { "Content-Type": "multipart/form-data" }
    };
    return result;
};

const getTextRequestData = (data, url) => {
    var result = {
        'method': "POST",
        'url': url,
        'data': data,
        headers: { "Content-Type": "text/plain" }
    };
    return result;
};
module.exports = { getFormRequestData, getTextRequestData }