class Counter {
    static #count = 17;
    static getCount(){
        return this.#count;
    }
    static increase(){
        return ++this.#count;
    }
    static decrease(){
        return --this.#count;
    }
}

module.exports = Counter;